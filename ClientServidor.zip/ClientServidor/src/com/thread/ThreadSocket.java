package com.thread;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.lang.management.ManagementFactory;
import java.lang.management.OperatingSystemMXBean;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.Socket;
import java.net.URL;
import java.util.Date;
import java.net.NetworkInterface;
import java.net.InetAddress;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.conf.ConfigurationBuilder;
import twitter4j.Trend;
import twitter4j.Trends;

import com.view.ServidorFrm;

public class ThreadSocket implements Runnable {
	private Socket socket;
	private ServidorFrm view;

	public ThreadSocket(Socket socket, ServidorFrm view) {
		this.socket = socket;
		this.view = view;
	}

	@Override
	public void run() {
		//Thread que aguarda uma mensagem e responde pro cliente
		try {
			while (true) {
				PrintWriter pr = new PrintWriter(socket.getOutputStream());
				InputStreamReader in = new InputStreamReader(socket.getInputStream());
				BufferedReader bf = new BufferedReader(in);
				if (bf.ready()) {
					String txt = "";
					int i;
					while ((i = bf.read()) != 0) {
						if (i > 0) {
							char c = (char) i;
							txt = txt + String.valueOf(c);
						}
						if (!bf.ready()) {
							break;
						}
					}
					view.getTxImputMessages().setText(view.getTxImputMessages().getText() + " \n"
							+ socket.getRemoteSocketAddress() + " --> " + txt);
					pr.println(txt);
					//Tratando a mensagem de retorno.
					String retorno = tratarMensagemRetorno(txt);
					System.out.println(tratarMensagemRetorno(txt));
					pr.print("Servidor: " + retorno);
					pr.flush();
				}
				Thread.sleep(2000);
			}

		} catch (Exception e) {
		}
	}

	private String tratarMensagemRetorno(String imput) throws IOException {
		String retorno = "";

		switch (imput) {
		case "/quem":
			retorno = "Servidor Cliente-Servidor TCP.";
			break;
		case "/ip":
			//pegamos o ip da maquina.
	        String ipDaMaquina = InetAddress.getLocalHost().getHostAddress();
			retorno = "\nIp: " + ipDaMaquina;
			break;
		case "/mac":
			InetAddress localHost = InetAddress.getLocalHost();
			NetworkInterface ni = NetworkInterface.getByInetAddress(localHost);
			byte[] hardwareAddress = ni.getHardwareAddress();

			String[] hexadecimal = new String[hardwareAddress.length];
			for (int i = 0; i < hardwareAddress.length; i++) {
				hexadecimal[i] = String.format("%02X", hardwareAddress[i]);
			}
			String macAddress = String.join("-", hexadecimal);

			retorno = macAddress;
			break;
		case "/sys":
			String OS = System.getProperty("os.name");
			retorno = OS;
			break;
		case "/dev":
			retorno = "Mansur Sausen,Rogus Staub, Gabriel Quadro, Douglas Kuhn, Henrique Fava.";
			break;
		case "/info":
			String userName = System.getProperty("user.name");
			long diskSize = new File("/").getTotalSpace();
			String arquitetura = System.getProperty("os.arch");
			String OSsistema = System.getProperty("os.name");
			String OSversion = System.getProperty("os.version");
			long Freemen = getFreeMemoryComputer();
			long Totalmen = getTotalMemoryComputer();
			
			
			retorno = "\nNome maquina: " + InetAddress.getLocalHost().getHostName() + "\nMem�ria livre: " + Freemen + "\nMem�ria total: " + Totalmen +
					"\nUsername: " + userName + "\nTamanho do disco: " + diskSize
					+ "\nArquitetura do sistema operacional: " + arquitetura + "\nSO: " + OSsistema + " vers�o " + OSversion;		
			break;
		case "/d�lar":
			try {
				// Verifica o valor da moeda com base USD para a moeda BRL
				URL url = new URL("https://api.exchangeratesapi.io/latest?base=USD&symbols=BRL");
				HttpURLConnection con = (HttpURLConnection) url.openConnection();
				con.setRequestMethod("GET");

				BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));

				String inputLine = "";
				while ((inputLine = in.readLine()) != null) {
					retorno = "O d�lar est� valendo " + inputLine.substring(16, 20) + "reais";
				}
			} catch (ProtocolException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "/trends":
			ConfigurationBuilder cb = new ConfigurationBuilder();
			cb.setDebugEnabled(true).setOAuthConsumerKey("3jmA1BqasLHfItBXj3KnAIGFB")
					.setOAuthConsumerSecret("imyEeVTctFZuK62QHmL1I0AUAMudg5HKJDfkx0oR7oFbFinbvA")
					.setOAuthAccessToken("265857263-pF1DRxgIcxUbxEEFtLwLODPzD3aMl6d4zOKlMnme")
					.setOAuthAccessTokenSecret("uUFoOOGeNJfOYD3atlcmPtaxxniXxQzAU4ESJLopA1lbC");
			TwitterFactory tf = new TwitterFactory(cb.build());
			Twitter twitter = tf.getInstance();
			Trends trends;
			try {
				//esse � WOEID do Brasil
				trends = twitter.getPlaceTrends(23424768);
				int count = 0;
				for (Trend trend : trends.getTrends()) {
					if (count < 10) {
						retorno = retorno +  "\n" +trend.getName();
						System.out.println(trend.getName());
						count++;
					}
				}
			} catch (TwitterException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			break;
		case "/data":
			Date data = new Date();
			retorno = data.toString();
			break;
		default:
			retorno = "Mensagem inv�lida";
		}
		return retorno;
	}
	
	private long getFreeMemoryComputer() {
	    try {
	        OperatingSystemMXBean system = ManagementFactory.getOperatingSystemMXBean();
	        Method getFreeMemory = system.getClass().getMethod("getFreePhysicalMemorySize");
	        getFreeMemory.setAccessible(true);
	        return (long) getFreeMemory.invoke(system);
	    } catch (Exception e) {
	        return -1;
	    }
	}

	private long getTotalMemoryComputer() {
	    try {
	        OperatingSystemMXBean system = ManagementFactory.getOperatingSystemMXBean();
	        Method getTotalMemory = system.getClass().getMethod("getTotalPhysicalMemorySize");
	        getTotalMemory.setAccessible(true);
	        return (long) getTotalMemory.invoke(system);
	    } catch (Exception e) {
	        return -1;
	    }
	}

}
