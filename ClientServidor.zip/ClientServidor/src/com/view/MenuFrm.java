package com.view;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextPane;

import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;

@SuppressWarnings({ "deprecation", "serial" })
public class MenuFrm extends JFrame{
	
	public final String STATUS_CLIENTE = "CLIENTES CONECTADOS: ";
	public final String STATUS_SERVIDOR = "STATUS SERVIDOR: ";
	private Integer clientesConectados;
	private JButton btNovoCliente;
	private JButton btCriarServidor;
	private JTextPane txStatusCliente;
	private JTextPane txStatusServidor;
	
	public MenuFrm(){
		initComponents();
		initListeners();
		initLayout();
		this.setTitle("MENU");
		this.setResizable(false);
		this.pack();
		this.setVisible(true);
	}

	private void initLayout() {
		// Inicializando o layout
		FormLayout layout = new FormLayout("pref, 3dlu, pref", "18dlu, 18dlu, 18dlu");      
		PanelBuilder builder = new PanelBuilder(layout);
		builder.setDefaultDialogBorder();
		CellConstraints cc = new CellConstraints();
		builder.add(btNovoCliente, cc.xy(1,1));
		builder.add(btCriarServidor, cc.xy(3,1));
		builder.add(txStatusCliente, cc.xyw(1,2, 3));
		builder.add(txStatusServidor, cc.xyw(1,3, 3));
		
		this.add(builder.getPanel(), BorderLayout.CENTER);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	private void initListeners() {
		//Adicionando o listener do bot�o do cliente
		btNovoCliente.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				new ClienteFrm(MenuFrm.this);
				
			}
		});
		//Adicionando o listener do bot�o do servidor
		btCriarServidor.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				new ServidorFrm(MenuFrm.this);
				btCriarServidor.setEnabled(false);
			}
		});
		
		
	}

	private void initComponents() {
		// Inicializando componentes
		btNovoCliente = new JButton("Novo Cliente");
		btNovoCliente.setEnabled(false);
		clientesConectados = 0;
		btCriarServidor = new JButton("Inicializar Servidor");
		txStatusCliente = new JTextPane();
		txStatusCliente.setText(STATUS_CLIENTE + clientesConectados);
		txStatusCliente.setEditable(false);
		txStatusServidor = new JTextPane();
		txStatusServidor.setText(STATUS_SERVIDOR + "INATIVO");
		txStatusServidor.setEditable(false);
	}

	public JButton getBtNovoCliente() {
		return btNovoCliente;
	}

	public void setBtNovoCliente(JButton btNovoCliente) {
		this.btNovoCliente = btNovoCliente;
	}

	public JButton getBtCriarServidor() {
		return btCriarServidor;
	}

	public void setBtCriarServidor(JButton btCriarServidor) {
		this.btCriarServidor = btCriarServidor;
	}

	public Integer getClientesConectados() {
		return clientesConectados;
	}

	public void setClientesConectados(Integer clientesConectados) {
		this.clientesConectados = clientesConectados;
	}

	public JTextPane getTxStatusCliente() {
		return txStatusCliente;
	}

	public void setTxStatusCliente(JTextPane txStatusCliente) {
		this.txStatusCliente = txStatusCliente;
	}

	public JTextPane getTxStatusServidor() {
		return txStatusServidor;
	}

	public void setTxStatusServidor(JTextPane txStatusServidor) {
		this.txStatusServidor = txStatusServidor;
	}
}
