package com.view;

import java.awt.BorderLayout;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import javax.swing.JFrame;
import javax.swing.JTextPane;

import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;
import com.thread.ThreadSocket;

@SuppressWarnings({ "deprecation", "serial" })
public class ServidorFrm extends JFrame{
	private MenuFrm pai;
	private JTextPane txImputMessages;
	private ServerSocket serverSocket;
	
	public ServidorFrm(MenuFrm pai){
		this.pai = pai;
		initComponents();
		initListeners();
		initLayout();
		setStatusServidor("ATIVO");
		this.setTitle("SERVIDOR");
		this.setSize(400, 600);
		this.setResizable(false);
		this.setVisible(true);
		pai.getBtNovoCliente().setEnabled(true);
		//toda vez que o servidor � inicializado, essa thread � lan�ada:
		new Thread(escuta).start();
	}

	private void initLayout() {
		//Inicializando layout
		FormLayout layout = new FormLayout("pref:grow", "f:18dlu:grow");      
		PanelBuilder builder = new PanelBuilder(layout);
		builder.setDefaultDialogBorder();
		CellConstraints cc = new CellConstraints();
		
		builder.add(txImputMessages, cc.xy(1,1));
		this.add(builder.getPanel(), BorderLayout.CENTER);
		this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
	}

	private void initListeners() {

	}

	private void initComponents() {
		//Inicializando componentes
		txImputMessages = new JTextPane();
		txImputMessages.setEditable(false);
		try {
			serverSocket = new ServerSocket(8899);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private void setStatusServidor(String status) {
		pai.getTxStatusServidor().setText(pai.STATUS_SERVIDOR + status);
	}
    private Runnable escuta = new Runnable() {
    	//Thread que aguarda um cliente se conectar e lan�a uma ThreadSocket
        public void run() {
            try{
            	while (true){
            		Socket s = serverSocket.accept();
            		// A Thread ThreadSocket vai aguardar uma mensagem para fazer o tratamento
                	new Thread(new ThreadSocket(s, ServidorFrm.this)).start();
                	Thread.sleep(2000);
				}
            } catch (Exception e){}
       }
    };

	public JTextPane getTxImputMessages() {
		return txImputMessages;
	}

	public void setTxImputMessages(JTextPane txImputMessages) {
		this.txImputMessages = txImputMessages;
	}
    
    
}
