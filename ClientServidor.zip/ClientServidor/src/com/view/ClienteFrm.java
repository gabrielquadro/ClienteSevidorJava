package com.view;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;

@SuppressWarnings({ "deprecation", "serial" })
public class ClienteFrm extends JFrame {
	private JScrollPane scroll;
	private MenuFrm pai;
	private JTextField txMensagem;
	private JTextArea txPainelRetorno;
	private JButton enviarMensagem;
	private Socket socket;
	
	public ClienteFrm(MenuFrm pai){
		this.pai = pai;
		initComponents();
		initListeners();
		initLayout();
		addClienteConectado();
		this.setTitle("CLIENTE - " + pai.getClientesConectados());
		this.setSize(400, 600);
		this.setResizable(false);
		this.setVisible(true);
	}

	private void initLayout() {
		//Inicializando layout
		FormLayout layout = new FormLayout("pref:grow, pref", "f:18dlu, 8dlu,  f:pref:grow");      
		PanelBuilder builder = new PanelBuilder(layout);
		builder.setDefaultDialogBorder();
		CellConstraints cc = new CellConstraints();
		builder.add(enviarMensagem, cc.xy(2,1));
		builder.add(txMensagem, cc.xy(1,1));
		builder.add(scroll, cc.xyw(1,3,2));
		this.add(builder.getPanel(), BorderLayout.CENTER);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	}

	private void initListeners() {
		//Adicionando listener se fechar a tela.
		this.addWindowListener(new java.awt.event.WindowAdapter() {
		    @Override
		    public void windowClosing(java.awt.event.WindowEvent e) {
		    	removeClienteConectado();
		    }
		});
		//Adicionando listener no botao que envia a mensagem
		enviarMensagem.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				String mensagem = txMensagem.getText();
				PrintWriter pr;
				try {
					pr = new PrintWriter(socket.getOutputStream());
					//printa mensagem do cliente
					pr.print(mensagem);
					pr.flush();
					// thread que vai fazer o controle das mensagens
					new Thread(escuta).start(); //sempre que uma mensagem for enviada, uma nova thread � executada:// thread que vai fazer o controle das mensagens
				} catch (IOException e) {
					e.printStackTrace();
				}
				txMensagem.setText("");	
		}});
	}

	private void initComponents() {
		//Inicializando componentes
		txMensagem = new JTextField();
		txMensagem.setEditable(true);
		txPainelRetorno = new JTextArea();
		txPainelRetorno.setEditable(false);
		scroll = new JScrollPane(txPainelRetorno);
		enviarMensagem = new JButton("Enviar");
		try {
			socket = new Socket("localHost", 8899);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void addClienteConectado() {
		//Adiciona +1 cliente no form
		pai.setClientesConectados(pai.getClientesConectados() + 1);
		pai.getTxStatusCliente().setText(pai.STATUS_CLIENTE + pai.getClientesConectados());
	}
	private void removeClienteConectado() {
		//Adiciona -1 cliente no form
		pai.setClientesConectados(pai.getClientesConectados() - 1);
		pai.getTxStatusCliente().setText(pai.STATUS_CLIENTE + pai.getClientesConectados());
	}
	
    private Runnable escuta = new Runnable() {
    	//Thread que envia a mensagem e aguarda um retorno
        public void run() {
            try{
				while (true) {
					InputStreamReader in = new InputStreamReader(socket.getInputStream());
					// Fica aqui aguardando at� receber uma mensagem de retorno.
	        		BufferedReader bf = new BufferedReader(in);
	        		if(bf.ready()) { // se bf.ready() = true ent�o o servidor retornou algo
	        			String txt = "";
	            		int i;
	            		while ((i = bf.read()) != 0){
	            		   if (i > 0){
	            		      char c = (char) i;
	            		      txt = txt + String.valueOf(c);
	            		   }
	            		   if(!bf.ready()) {
	            			   break;
	            		   }
	            		}
	            		// imprimindo no painel
	            		txPainelRetorno.setText(txPainelRetorno.getText() + "\n" + txt);
	        		};
	        		Thread.sleep(2000);
				}
            } catch (Exception e){}
       }
    };
}
